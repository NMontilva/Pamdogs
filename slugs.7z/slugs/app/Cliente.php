<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\SluggableInterface;
use Cviebrock\EloquentSluggable\SluggableTrait;

class Cliente extends Model implements SluggableInterface
{

	use SluggableTrait;

    protected $table = "clientes";

    protected $fillable = ['nombres','apellido','cedula','edad','telefono_habitacion','telefono_movil','sexo','direccion','descripcion','estatus','id_user'];

    protected $sluggable = [
        'build_from' => 'nombres',
        'save_to' => 'slug',
    ];
}
