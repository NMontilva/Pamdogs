<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class UserRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'min:4|max:120|required|alpha|',
            'email' => 'min:4|max:250|required|email|unique:users|',
            'password'=> 'min:4|max:18|required|numeric|',

        ];
    }
    public function messages()
{
    return [
        'password.required' => 'Es necesaria una contraseña.',
        'password.numeric' => 'La contraseña debe contener solo numeros.',
        'email.unique' => 'Debe ser unico, esta es unica.',
        'email.email' => 'Esta validacion es personalizada el email debe ser un email.',
        'name.alpha' => 'No eres un robot ni gringo, no tienes numeros en tu nombre. Por si no te das cuenta es unico.'
    ];
}
}
