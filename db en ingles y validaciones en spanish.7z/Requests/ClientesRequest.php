<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class ClientesRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'min:4|max:120|required',
            'lastname' => 'min:4|max:120|required',
            'idnumber' => 'required|numeric|unique:clientes',
            'age' => 'min:4|max:120|required|numeric',
            'phone_home' => 'numeric',
            'phone_mobile' => 'numeric',
            'direction' => 'min:4|max:120|required',
            'description' => 'min:4|max:255|required',
        ];
    }
}
