-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-01-2017 a las 00:58:02
-- Versión del servidor: 10.0.17-MariaDB
-- Versión de PHP: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pets_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `access`
--

CREATE TABLE `access` (
  `id_access` int(11) NOT NULL,
  `id_profile` int(11) DEFAULT NULL,
  `id_module` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clients`
--

CREATE TABLE `clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `idnumber` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `phone_home` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone_mobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sex` enum('masculino','femenino') COLLATE utf8_unicode_ci NOT NULL,
  `direction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_unicode_ci NOT NULL,
  `id_user` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `clients`
--

INSERT INTO `clients` (`id`, `name`, `lastname`, `idnumber`, `age`, `phone_home`, `phone_mobile`, `sex`, `direction`, `description`, `status`, `id_user`, `created_at`, `updated_at`, `slug`) VALUES
(2, 'Aquiles', 'Brinco', '15165484', 22, '12312312', '123123123', 'masculino', 'asdads', 'adasdadsadsdasd', 'activo', 3, '2017-01-20 09:47:16', '2017-01-25 06:07:13', 'aquiles'),
(3, 'Esteban', 'Dido', '123123123123', 12, '12323132', '123132113', 'masculino', 'adasd', 'asdasdas', 'activo', 9, '2017-01-25 03:53:35', '2017-01-25 03:53:35', 'esteban');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contract`
--

CREATE TABLE `contract` (
  `id` int(11) NOT NULL,
  `id_client` int(11) DEFAULT NULL,
  `id_employee` int(11) DEFAULT NULL,
  `id_services` int(11) DEFAULT NULL,
  `date_start_contract` varchar(255) DEFAULT NULL,
  `date_end_contract` varchar(255) DEFAULT NULL,
  `description_contract` varchar(255) DEFAULT NULL,
  `status_contract` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contract_status`
--

CREATE TABLE `contract_status` (
  `id` int(11) NOT NULL,
  `description_contract_status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `department`
--

CREATE TABLE `department` (
  `id_department` int(11) NOT NULL,
  `name_department` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `employees`
--

CREATE TABLE `employees` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `idnumber` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `phone_home` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone_mobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `direction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_department` int(11) NOT NULL,
  `id_municipality` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2017_01_12_001622_add_categoria_table', 1),
('2017_01_12_002936_add_empleados_table', 2),
('2017_01_12_002953_add_clientes_table', 2),
('2017_01_14_045618_create_oauth_identities_table', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `module`
--

CREATE TABLE `module` (
  `id_module` int(11) NOT NULL,
  `name_module` varchar(255) DEFAULT NULL,
  `status_module` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipio`
--

CREATE TABLE `municipio` (
  `id_municipio` int(11) NOT NULL,
  `id_departamento` int(11) DEFAULT NULL,
  `nombre_municipio` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_identities`
--

CREATE TABLE `oauth_identities` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `provider_user_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `access_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `observations_contract`
--

CREATE TABLE `observations_contract` (
  `id` int(11) NOT NULL,
  `id_contract` int(11) DEFAULT NULL,
  `id_employee` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `observation_contract` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pet`
--

CREATE TABLE `pet` (
  `id` int(11) NOT NULL,
  `id_owner` int(11) DEFAULT NULL,
  `name_pet` varchar(255) DEFAULT NULL,
  `id_species_pet` int(11) DEFAULT NULL,
  `sex_pet` varchar(255) DEFAULT NULL,
  `age_pet` varchar(255) DEFAULT NULL,
  `race_pet` varchar(255) DEFAULT NULL,
  `status_pet` int(11) DEFAULT NULL,
  `description_pet` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pet_habits`
--

CREATE TABLE `pet_habits` (
  `id` int(11) NOT NULL,
  `id_pet` int(11) DEFAULT NULL,
  `description_pet_habits` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pet_health`
--

CREATE TABLE `pet_health` (
  `id` int(11) NOT NULL,
  `id_pet` int(11) DEFAULT NULL,
  `health_issue_pet` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pet_species`
--

CREATE TABLE `pet_species` (
  `id` int(11) NOT NULL,
  `species` varchar(255) DEFAULT NULL,
  `status_species` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `services`
--

CREATE TABLE `services` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_services` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cost_services` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description_services` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status_services` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `services`
--

INSERT INTO `services` (`id`, `name_services`, `cost_services`, `description_services`, `status_services`, `created_at`, `updated_at`) VALUES
(2, 'Cuidado de Mascota', '3000', 'Cuidado', 'Activo', '2017-01-12 07:15:19', '2017-01-12 07:15:19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `services_employees`
--

CREATE TABLE `services_employees` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_services` int(10) UNSIGNED NOT NULL,
  `id_employee` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `services_employees`
--

INSERT INTO `services_employees` (`id`, `id_services`, `id_employee`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '2017-01-18 04:00:00', '2017-01-18 04:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('cliente','empleado','admin') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'cliente',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `type`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Prueba', 'prueba@gmail.com', '$2y$10$qrB8NVHhBxT1UGHUxlqxO.ZEA3qoUHrWWjFiJeL4o/DFcpwnBz9xO', 'cliente', NULL, '2017-01-12 06:54:52', '2017-01-20 08:31:55'),
(2, 'Admin_prueba', 'adminprueba@gmail.com', '$2y$10$.dVOy51VXS1VHSxl.K5vwuJc3Tm.qHm1JTfBimPrbtxQmXxOn7Gtq', 'admin', NULL, '2017-01-12 06:56:19', '2017-01-12 06:56:19'),
(3, 'Prueba 2', 'prueba2@gmail.com', '$2y$10$rosTAMV1zOOPZNJ5MeG/G.95gADIGOluqbAc4wwLZkd0NSnwdCZ4u', 'cliente', NULL, '2017-01-12 09:29:18', '2017-01-12 09:29:18'),
(9, 'Prueba4', 'prueba4@gmail.com', '$2y$10$BoEvSp6u.YSwLCKoK7aLoObKxjryA0UCa0cPC0cFg6/zpJ1A0a5ly', 'empleado', NULL, '2017-01-20 05:04:04', '2017-01-20 05:04:04'),
(10, 'Prueba 6', 'prueba6@gmail.com', '$2y$10$QABJRCBLyPLTGX2MWOdOyeRCKlKa0edZFNFZ7UFDqHDwqmz2aM.Oe', 'empleado', NULL, '2017-01-25 03:50:01', '2017-01-25 03:50:01'),
(11, 'testa', 'testa@gmail.com', '$2y$10$EMedST02gqlT9HIAeD4K2.DTEoNoQB3CPY6EHNkhRBrV9KaCb10sS', 'cliente', NULL, '2017-01-25 03:51:45', '2017-01-25 03:51:45');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `access`
--
ALTER TABLE `access`
  ADD PRIMARY KEY (`id_access`);

--
-- Indices de la tabla `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `contract_status`
--
ALTER TABLE `contract_status`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id_department`);

--
-- Indices de la tabla `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empleados_mas_id_user_foreign` (`id_user`);

--
-- Indices de la tabla `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`id_module`);

--
-- Indices de la tabla `municipio`
--
ALTER TABLE `municipio`
  ADD PRIMARY KEY (`id_municipio`);

--
-- Indices de la tabla `oauth_identities`
--
ALTER TABLE `oauth_identities`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `observations_contract`
--
ALTER TABLE `observations_contract`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indices de la tabla `pet`
--
ALTER TABLE `pet`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pet_habits`
--
ALTER TABLE `pet_habits`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pet_health`
--
ALTER TABLE `pet_health`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pet_species`
--
ALTER TABLE `pet_species`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `services_employees`
--
ALTER TABLE `services_employees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mas_servicios_empleados_id_servicios_foreign` (`id_services`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `access`
--
ALTER TABLE `access`
  MODIFY `id_access` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `contract`
--
ALTER TABLE `contract`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `contract_status`
--
ALTER TABLE `contract_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `department`
--
ALTER TABLE `department`
  MODIFY `id_department` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `module`
--
ALTER TABLE `module`
  MODIFY `id_module` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `municipio`
--
ALTER TABLE `municipio`
  MODIFY `id_municipio` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `oauth_identities`
--
ALTER TABLE `oauth_identities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `pet`
--
ALTER TABLE `pet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `pet_habits`
--
ALTER TABLE `pet_habits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `pet_health`
--
ALTER TABLE `pet_health`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `pet_species`
--
ALTER TABLE `pet_species`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `services`
--
ALTER TABLE `services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `services_employees`
--
ALTER TABLE `services_employees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `empleados_mas_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `services_employees`
--
ALTER TABLE `services_employees`
  ADD CONSTRAINT `mas_servicios_empleados_id_servicios_foreign` FOREIGN KEY (`id_services`) REFERENCES `services` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
