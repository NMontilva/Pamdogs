@extends('admin.template.main')

@section('title','Usuarios Registrados')


@section('content')

	<legend>Listado</legend>

	<a href="{{route('admin.clientes.create')}}" class="btn btn-default">Registrar nuevo cliente</a>
	<table class="table table-striped">
		<thead>
			<th>ID</th>
			<th>Nombre</th>
			<th>Cedula</th>
			<th>Edad</th>
			<th>Telefono Habitacion</th>
			<th>Telefono Movil</th>
			<th>Sexo</th>
			<th>Direccion</th>
			<th>Descripcion</th>
			<th>Estatus</th>
		</thead>
		<tbody>
			@foreach($clientes as $cliente)
				<tr>
					<td>{{ $cliente->id}}</td>
					<td>{{ $cliente->name.' '.$cliente->lastname}}</td>
					<td>{{ $cliente->idnumber}}</td>
					<td>{{ $cliente->age}}</td>
					<td>{{ $cliente->phone_home}}</td>
					<td>{{ $cliente->phone_mobile}}</td>
					<td>{{ $cliente->sex}}</td>
					<td>{{ $cliente->direction}}</td>
					<td>{{ $cliente->description}}</td>
					<td>{{ $cliente->status}}</td>
					<td><a href="{{ route('admin.clientes.edit', $cliente->slug) }}" class="btn btn-warning"><span class="glyphicon glyphicon-wrench"></span></a><a href="{{ route('admin.clientes.destroy', $cliente->slug) }}" class="btn btn-danger" aria-hidden="true" onclick="return confirm('Seguro desea elimiar al usuario?')"><span class="glyphicon glyphicon-remove-circle" oncl aria-hidden="true"></span></a></td>
				</tr>
			@endforeach
		</tbody>
	</table>
	{!! $clientes->render() !!}
@endsection