@extends('admin.template.main')

@section('title','Registrar Cliente')

@section('content')

	<legend>Registro de Clientes</legend>

	{!! Form::open(['route'=>'admin.clientes.store', 'method' => 'POST']) !!}

		<div class="form-group">
			{!! Form::label('name', 'Nombres') !!}
			{!! Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Nombres', 'required']) !!}
		</div>

		<div class="form-group">
			{!! Form::label('lastname', 'Apellidos') !!}
			{!! Form::text('lastname', null, ['class' => 'form-control', 'placeholder' => 'Apellidos', 'required']) !!}
		</div>

		<div class="form-group">
			{!! Form::label('idnumber', 'Cedula') !!}
			{!! Form::text('idnumber', null, ['class' => 'form-control', 'placeholder' => 'Cedula de Identidad', 'required']) !!}
		</div>
				<div class="form-group">
			{!! Form::label('age', 'Edad') !!}
			{!! Form::text('age', null, ['class' => 'form-control', 'placeholder' => 'Edad', 'required']) !!}
		</div>

		<div class="form-group">
			{!! Form::label('phone_home', 'Telefono de Habitacion') !!}
			{!! Form::text('phone_home', null, ['class' => 'form-control', 'placeholder' => 'Telefono de Habitacion', 'required']) !!}
		</div>

		<div class="form-group">
			{!! Form::label('phone_mobile', 'Telefono Movil') !!}
			{!! Form::text('phone_mobile', null, ['class' => 'form-control', 'placeholder' => 'Telefono Movil', 'required']) !!}
		</div>

		<div class="form-group">
			{!! Form::label('sex','Sexo') !!}
			{!! Form::select('sex', ['' => 'Seleccione su sexo','masculino' => 'Masculino', 'femenino' => 'Femenino'], null, ['class'=>'form-control']) !!}
		</div>

		<div class="form-group">
			{!! Form::label('direction', 'Direccion') !!}
			{!! Form::text('direction', null, ['class' => 'form-control', 'placeholder' => 'Direccion', 'required']) !!}
		</div>

		<div class="form-group">
			{!! Form::label('description', 'Descripcion') !!}
			{!! Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => 'Descripcion', 'required']) !!}
		</div>

		<div class="form-group">
			{!! Form::label('status','Estatus') !!}
			{!! Form::select('status', ['' => 'Seleccione el estado del sujeto','activo' => 'Activo', 'inactivo' => 'Inactivo'], null, ['class'=>'form-control']) !!}
		</div>

		<div class="form-group">
			{!! Form::submit('Registrar', ['class' => 'btn btn-primary']) !!}
		</div>

	{!! Form::close() !!}
 
@endsection