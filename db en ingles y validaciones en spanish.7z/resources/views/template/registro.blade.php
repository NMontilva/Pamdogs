<!DOCTYPE html>
<html class="nojs html" lang="es-ES">
 <head>

  <script type="text/javascript">
   if(typeof Muse == "undefined") window.Muse = {}; window.Muse.assets = {"required":["jquery-1.8.3.min.js", "museutils.js", "webpro.js", "jquery.watch.js", "registro.css"], "outOfDate":[]};
</script>
  
  <meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
  <meta name="generator" content="2015.1.0.342"/>
  <title>registro</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="css/site_global.css?522193581"/>
  <link rel="stylesheet" type="text/css" href="css/master_a-p_g_-maestra.css?3829301669"/>
  <link rel="stylesheet" type="text/css" href="css/registro.css?156750615" id="pagesheet"/>
  <!-- IE-only CSS -->
  <!--[if lt IE 9]>
  <link rel="stylesheet" type="text/css" href="css/iefonts_registro.css?4041188845"/>
  <![endif]-->
  <!-- Other scripts -->
  <script type="text/javascript">
   document.documentElement.className = document.documentElement.className.replace(/\bnojs\b/g, 'js');
var __adobewebfontsappname__ = "muse";
</script>
  <!-- JS includes -->
  <script type="text/javascript">
   document.write('\x3Cscript src="' + (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//webfonts.creativecloud.com/source-sans-pro:n6,i7,n7,n3:default.js" type="text/javascript">\x3C/script>');
</script>
   </head>
 <body>

  <div class="clearfix borderbox" id="page"><!-- group -->
   <div class="clearfix grpelem" id="pu137"><!-- group -->
    <div class="browser_width" id="u137-bw">
     <div id="u137"><!-- simple frame --></div>
    </div>
    <a class="nonblock nontext" id="u187" href="index.html"><!-- simple frame --></a>
   </div>
   <div class="clearfix grpelem" id="pu1198"><!-- group -->
    <div class="grpelem" id="u1198"><!-- simple frame --></div>
    <div class="clearfix grpelem" id="u1201-4"><!-- content -->
     <p>Regístrate</p>
    </div>
    <form class="form-grp clearfix grpelem" id="widgetu1260" method="post" enctype="multipart/form-data" action="scripts/form-u1260.php"><!-- none box -->
     <div class="fld-grp clearfix grpelem" id="widgetu1262" data-required="true" data-type="email"><!-- none box -->
      <span class="fld-input NoWrap actAsDiv rounded-corners transition clearfix grpelem" id="u1264-4"><!-- content --><input class="wrapped-input" type="email" spellcheck="false" id="widgetu1262_input" name="Email" tabindex="1"/><label class="wrapped-input fld-prompt" id="widgetu1262_prompt" for="widgetu1262_input"><span class="actAsPara">&nbsp; Dirección de email.</span></label></span>
     </div>
     <div class="clearfix grpelem" id="u1261-4"><!-- content -->
      <p>Enviando formulario...</p>
     </div>
     <div class="clearfix grpelem" id="u1274-4"><!-- content -->
      <p>El servidor ha detectado un error.</p>
     </div>
     <div class="clearfix grpelem" id="u1276-4"><!-- content -->
      <p>Formulario recibido.</p>
     </div>
     <input class="submit-btn NoWrap grpelem" id="u1275-17" type="submit" value="" tabindex="2"/><!-- state-based BG images -->
    </form>
    <div class="Button shadow rounded-corners clearfix grpelem" id="buttonu1312"><!-- container box -->
     <div class="clearfix grpelem" id="u1313-4"><!-- content -->
      <p>Registrarte con Facebook</p>
     </div>
    </div>
    <div class="rounded-corners grpelem" id="u1340"><!-- simple frame --></div>
    <div class="rounded-corners grpelem" id="u1343"><!-- simple frame --></div>
    <div class="clearfix grpelem" id="u1347-5"><!-- content -->
     <p>¿Ya eres miembro? <span id="u1347-2">Accede aquí</span></p>
    </div>
    <div class="clearfix grpelem" id="u1357-5"><!-- content -->
     <p id="u1357-3"><span id="u1357">Tomaremos algunos datos de tu perfil de Facebook para realizar tu registro</span><span id="u1357-2">.</span></p>
    </div>
    <div class="clearfix grpelem" id="u1351-8"><!-- content -->
     <p><span id="u1351">Al registrarte estás aceptando nuestros</span> <span id="u1351-3">términos y condiciones </span><span id="u1351-4">y </span><span id="u1351-5">política de privacidad.</span></p>
    </div>
   </div>
   <div class="verticalspacer"></div>
  </div>
  <div class="preload_images">
   <img class="preload" src="images/u1275-17-r.png" alt=""/>
   <img class="preload" src="images/u1275-17-m.png" alt=""/>
   <img class="preload" src="images/u1275-17-fs.png" alt=""/>
   <img class="preload" src="images/f.png" alt=""/>
   <!--[if lt IE 9]>
   <img class="preload" src="images/f-iebuttonu1312-fr.png" alt=""/>
   <![endif]-->
  </div>
  <!-- JS includes -->
  <script type="text/javascript">
   if (document.location.protocol != 'https:') document.write('\x3Cscript src="http://musecdn.businesscatalyst.com/scripts/4.0/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script type="text/javascript">
   window.jQuery || document.write('\x3Cscript src="scripts/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script src="scripts/museutils.js?4190794036" type="text/javascript"></script>
  <script src="scripts/whatinput.js?84559013" type="text/javascript"></script>
  <script src="scripts/webpro.js?488283310" type="text/javascript"></script>
  <script src="scripts/jquery.watch.js?349565855" type="text/javascript"></script>
  <!-- Other scripts -->
  <script type="text/javascript">
   $(document).ready(function() { try {
(function(){var a={},b=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),16);return 0};(function(){$('link[type="text/css"]').each(function(){var b=($(this).attr("href")||"").match(/\/?css\/([\w\-]+\.css)\?(\d+)/);b&&b[1]&&b[2]&&(a[b[1]]=b[2])})})();(function(){$("body").append('<div class="version" style="display:none; width:1px; height:1px;"></div>');
for(var c=$(".version"),d=0;d<Muse.assets.required.length;){var f=Muse.assets.required[d],g=f.match(/([\w\-\.]+)\.(\w+)$/),k=g&&g[1]?g[1]:null,g=g&&g[2]?g[2]:null;switch(g.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");c.addClass(k);var g=b(c.css("color")),h=b(c.css("background-color"));g!=0||h!=0?(Muse.assets.required.splice(d,1),"undefined"!=typeof a[f]&&(g!=a[f]>>>24||h!=(a[f]&16777215))&&Muse.assets.outOfDate.push(f)):d++;c.removeClass(k);break;case "js":k.match(/^jquery-[\d\.]+/gi)&&
typeof $!="undefined"?Muse.assets.required.splice(d,1):d++;break;default:throw Error("Unsupported file type: "+g);}}c.remove();if(Muse.assets.outOfDate.length||Muse.assets.required.length)c="Puede que determinados archivos falten en el servidor o sean incorrectos. Limpie la cache del navegador e inténtelo de nuevo. Si el problema persiste, póngase en contacto con el administrador del sitio web.",(d=location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi))&&Muse.assets.outOfDate.length&&(c+="\nOut of date: "+Muse.assets.outOfDate.join(",")),d&&Muse.assets.required.length&&(c+="\nMissing: "+Muse.assets.required.join(",")),alert(c)})()})();
/* body */
Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
Muse.Utils.prepHyperlinks(true);/* body */
Muse.Utils.fullPage('#page');/* 100% height page */
Muse.Utils.initWidget('#widgetu1260', ['#bp_infinity'], function(elem) { return new WebPro.Widget.Form(elem, {validationEvent:'submit',errorStateSensitivity:'high',fieldWrapperClass:'fld-grp',formSubmittedClass:'frm-sub-st',formErrorClass:'frm-subm-err-st',formDeliveredClass:'frm-subm-ok-st',notEmptyClass:'non-empty-st',focusClass:'focus-st',invalidClass:'fld-err-st',requiredClass:'fld-err-st',ajaxSubmit:true}); });/* #widgetu1260 */
Muse.Utils.showWidgetsWhenReady();/* body */
Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
} catch(e) { if (e && 'function' == typeof e.notify) e.notify(); else Muse.Assert.fail('Error calling selector function:' + e); }});
</script>
   </body>
</html>